Thank you for downloading the original Escape.wad. This wad has not been revised at all, all is the same. If you would like the revised version look at the website that you got this from. 
************************************************************************************************************************************************************
INSTALLATION:
to install this WAD simply drag it over the source port you use. Simple.
************************************************************************************************************************************************************
CONTACT ME:
If you have a comments or questions please email at jkstanw09@gmail.com.
************************************************************************************************************************************************************
KNOWN BUGS:
The end switch does not work. This is just apart of the original un-altered WAD.
************************************************************************************************************************************************************
STORY:
You wake up in your farm, hearing terrible things outside. Yesterday you decided not to evacuate the area to the bunker at the end of the village. The space marnies had told you that if you want to live you would have to evacuate, but you said no. so now you are stuck in a demon invaded earth with your shotgun and a pack of cigars. You have to get to that bunker.
************************************************************************************************************************************************************